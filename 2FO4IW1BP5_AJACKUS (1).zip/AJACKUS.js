const apiUrl = 'https://jsonplaceholder.typicode.com/users';

const addUserBtn = document.getElementById('addUserBtn');
const userFormContainer = document.getElementById('userFormContainer');
const userForm = document.getElementById('userForm');
const userList = document.getElementById('userList').getElementsByTagName('tbody')[0];

let currentEditUserId = null;

// Fetch and display users
async function fetchUsers() {
    try {
        const response = await fetch(apiUrl);
        const users = await response.json();

        userList.innerHTML = ''; // Clear the list before adding new data

        users.forEach(user => {
            const row = userList.insertRow();
            row.innerHTML = `
                <td>${user.id}</td>
                <td>${user.name.split(' ')[0]}</td>
                <td>${user.name.split(' ')[1]}</td>
                <td>${user.email}</td>
                <td>${user.company.name}</td>
                <td>
                    <button onclick="editUser(${user.id})">Edit</button>
                    <button onclick="deleteUser(${user.id})">Delete</button>
                </td>
            `;
        });
    } catch (error) {
        alert('Failed to fetch users.');
    }
}

// Show form for adding a new user
addUserBtn.addEventListener('click', () => {
    currentEditUserId = null;
    document.getElementById('formTitle').textContent = 'Add User';
    userForm.reset();
    userFormContainer.style.display = 'block';
});

// Handle user form submission (add/edit user)
userForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('email').value;
    const department = document.getElementById('department').value;

    const userData = {
        name: `${firstName} ${lastName}`,
        email,
        company: {
            name: department
        }
    };

    if (currentEditUserId) {
        // Edit existing user
        try {
            await fetch(`${apiUrl}/${currentEditUserId}`, {
                method: 'PUT',
                body: JSON.stringify(userData),
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            alert('User updated successfully.');
        } catch (error) {
            alert('Failed to update user.');
        }
    } else {
        // Add new user
        try {
            await fetch(apiUrl, {
                method: 'POST',
                body: JSON.stringify(userData),
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            alert('User added successfully.');
        } catch (error) {
            alert('Failed to add user.');
        }
    }

    userFormContainer.style.display = 'none';
    fetchUsers(); // Refresh user list
});

// Edit a user
function editUser(userId) {
    currentEditUserId = userId;
    document.getElementById('formTitle').textContent = 'Edit User';

    fetch(`${apiUrl}/${userId}`)
        .then(response => response.json())
        .then(user => {
            const nameParts = user.name.split(' ');
            document.getElementById('firstName').value = nameParts[0];
            document.getElementById('lastName').value = nameParts[1];
            document.getElementById('email').value = user.email;
            document.getElementById('department').value = user.company.name;
            userFormContainer.style.display = 'block';
        });
}

// Delete a user
async function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        try {
            await fetch(`${apiUrl}/${userId}`, {
                method: 'DELETE'
            });
            alert('User deleted successfully.');
            fetchUsers(); // Refresh user list
        } catch (error) {
            alert('Failed to delete user.');
        }
    }
}

// Initial fetch to load users
fetchUsers();